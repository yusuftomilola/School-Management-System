import MaleStudentsIcon from "./totalMaleStudentsIcon.svg";
import FemaleStudentsIcon from "./totalFemaleStudentsIcon.svg";
import TotalStudentsIcon from "./totalStudentsIcon.svg";

import StudentParentIcon from "./studentParentIcon.svg";
import StudentTeacherIcon from "./studentTeacherIcon.svg";
import MaleStudentIcon from "./maleStudentIcon.svg";
import FemaleStudentIcon from "./femaleStudentIcon.svg";

export {
  FemaleStudentsIcon,
  MaleStudentsIcon,
  TotalStudentsIcon,
  StudentParentIcon,
  StudentTeacherIcon,
  MaleStudentIcon,
  FemaleStudentIcon,
};
