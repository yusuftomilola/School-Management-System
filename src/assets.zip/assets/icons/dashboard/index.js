import StudentsIcon from "./dashboardStudentsIcon.svg";
import TeachersIcon from "./dashboardTeachersIcon.svg";
import ClassroomsIcon from "./dashboardClassroomsIcon.svg";
import SubjectsIcon from "./dashboardSubjectsIcon.svg";
import TwelvePercent from "./12PercentIcon.svg";

export {
  StudentsIcon,
  TeachersIcon,
  ClassroomsIcon,
  SubjectsIcon,
  TwelvePercent,
};
